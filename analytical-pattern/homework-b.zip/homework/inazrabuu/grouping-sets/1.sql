-- Player & Team: Player who has most points for one team
SELECT
	player_name,
	team_id,
	SUM(pts) AS total_points
FROM
	game_details
WHERE
	pts IS NOT NULL
GROUP BY 
	GROUPING SETS (
	(player_name, team_id)
)
ORDER BY
	total_points DESC
LIMIT 1