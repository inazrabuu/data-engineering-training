-- Player & Season: Player who has most points in a single season
SELECT
	gd.player_name,
	g.season,
	SUM(pts) AS total_points
FROM
	games g
	INNER JOIN game_details gd ON g.game_id = gd.game_id
WHERE
	gd.pts IS NOT NULL
GROUP BY
	GROUPING SETS (
	(gd.player_name, g.season)
)
ORDER BY
	total_points DESC
LIMIT 1